import time
from selenium import webdriver
driver = webdriver.Chrome(executable_path="C:/Users/ASUS/PycharmProjects/pythonProject/chromedriver.exe")
driver.get("https://www.materializecss.com/radio-buttons.html")
time.sleep(5)


radio= driver.find_elements_by_name('group1')
driver.find_element_by_xpath('//*[@id="radio"]/form/p[2]/label/span').click()
time.sleep(5)


for choice in radio:
    if(choice.is_selected()):
        assert choice.find_element_by_xpath('//*[@id="radio"]/form/p[2]/label/span').text=="Yellow"
        print("Radio button test passed")