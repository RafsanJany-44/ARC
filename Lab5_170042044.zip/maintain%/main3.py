from selenium import webdriver
from selenium.webdriver.support.select import Select
import time

driver=webdriver.Chrome(executable_path="/Users/rafsan/Desktop/maintain%/chromedriver")
driver.get('http://demo.guru99.com/test/newtours/register.php')
time.sleep(5)
dropdown = Select(driver.find_element_by_name("country"))
dropdown.select_by_visible_text("SPAIN")