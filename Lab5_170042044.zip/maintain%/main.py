from selenium import webdriver
import time
driver=webdriver.Chrome(executable_path="/Users/rafsan/Desktop/maintain%/chromedriver")

driver.get("https://www.facebook.com/")

time.sleep(5)

email=driver.find_element_by_id("email")

email.send_keys("rtrt@gmail.com")


passw=driver.find_element_by_id("pass")
passw.send_keys("ChromeDriver")
driver.find_element_by_name("login").submit()

time.sleep(5)

def testEmail():
    text=str(driver.find_element_by_id('email_container').text).lower()
    assert (text.lower()!="the email address or mobile number you entered isn't connected to an account. Find your account and log")
    print("Test Email Passed")

def testPassword():
    text=str(driver.find_element_by_xpath('//*[@id="loginform"]/div[2]/div[2]').text).lower()
    assert (not text.__contains__('the password that you\'ve entered is incorrect. forgotten password?'))
    print("Test Pass Passed")
testEmail()
testPassword()