
from selenium import webdriver

import time

driver=webdriver.Chrome(executable_path="/Users/rafsan/Desktop/maintain%/chromedriver")


currentUrl = 'https://materializecss.com/radio-buttons.html'
driver.get(currentUrl)
time.sleep(5)
driver.find_element_by_id('logo-container').click()
assert driver.current_url != currentUrl
print("Case passed")